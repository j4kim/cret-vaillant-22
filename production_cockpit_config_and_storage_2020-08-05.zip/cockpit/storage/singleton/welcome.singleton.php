<?php
 return array (
  'name' => 'welcome',
  'label' => 'welcome',
  '_id' => 'welcome5e14f7924ea1f',
  'fields' => 
  array (
    0 => 
    array (
      'name' => 'title',
      'label' => '',
      'type' => 'text',
      'default' => '',
      'info' => '',
      'group' => '',
      'localize' => false,
      'options' => 
      array (
      ),
      'width' => '1-1',
      'lst' => true,
      'acl' => 
      array (
      ),
    ),
    1 => 
    array (
      'name' => 'content',
      'label' => '',
      'type' => 'wysiwyg',
      'default' => '',
      'info' => '',
      'group' => '',
      'localize' => false,
      'options' => 
      array (
      ),
      'width' => '1-1',
      'lst' => true,
      'acl' => 
      array (
      ),
    ),
  ),
  'template' => '',
  'data' => NULL,
  '_created' => 1578432402,
  '_modified' => 1578497866,
  'description' => '',
  'acl' => 
  array (
    'public' => 
    array (
      'data' => true,
    ),
    'author' => 
    array (
      'edit' => false,
      'data' => false,
      'form' => true,
    ),
  ),
);