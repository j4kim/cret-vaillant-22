<?php

return [
    'app.name' => 'K-Linou',
    'groups' => [
        'author' => [
            '$admin' => false,
            'cockpit' => [
                'backend' => true,
                'finder' => false
            ],
            'collections' => [
                'manage' => true
            ],
            'singletons' => [
                'manage' => true
            ]
        ]
    ],
    'mailer' => [
        'from'       => 'cockpit@cret-vaillant.ch',
        'transport'  => 'smtp',
        'host'       => 'mail.infomaniak.com',
        'user'       => 'cockpit@cret-vaillant.ch',
        'password'   => 'Ah oui oui non',
        'port'       => 587,
        'auth'       => true,
        'encryption' => 'tls'
    ]
];
