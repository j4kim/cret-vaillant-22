<?php
 return array (
  'name' => 'contact',
  'label' => 'contact',
  '_id' => 'contact5e14f8d5befce',
  'fields' => 
  array (
    0 => 
    array (
      'name' => 'content',
      'label' => '',
      'type' => 'wysiwyg',
      'default' => '',
      'info' => '',
      'group' => '',
      'localize' => false,
      'options' => 
      array (
      ),
      'width' => '1-1',
      'lst' => true,
      'acl' => 
      array (
      ),
    ),
  ),
  'template' => '',
  'data' => NULL,
  '_created' => 1578432725,
  '_modified' => 1578497881,
  'description' => '',
  'acl' => 
  array (
    'public' => 
    array (
      'data' => true,
    ),
    'author' => 
    array (
      'form' => true,
      'edit' => false,
      'data' => false,
    ),
  ),
);